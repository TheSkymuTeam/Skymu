@echo off
echo - Importing Skype data

set file=protected-data.xml

echo - File: %file%
powershell.exe -ExecutionPolicy Bypass -NoLogo -NoProfile -File "%~dp0import-backend.ps1" -Import -Path "%file%" -Verbose

echo - Done
pause